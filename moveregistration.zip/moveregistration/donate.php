<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <!---<title> Responsive Registration Form | CodingLab </title>--->
    <link rel="stylesheet" href="style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>MoveBold Foundation-Registration Form-</title>
   </head>
<body>
  <div class="container">
    <center><h1>MoveBold Foundation</h1></center>
    

    <div class="title">Donate Now</div>
    <div class="content">
      <form action="select.php">
        <div class="user-details">
          <div class="input-box">
            <span class="details">Enter Your Amount:</span>
            <input type="text" placeholder="Enter Your Amount:" required>
          </div>
          <div class="input-box">
            <span class="details">Enter Your Email:</span>
            <input type="Email" placeholder="Enter Your Email:" required>
          </div>
          <div class="input-box">
            <span class="details">Enter Your Name: </span>
            <input type="text" placeholder="Enter Your Name: " required>
          </div>
          <div class="input-box">
            <span class="details">Enter Your Address:</span>
            <input type="text" placeholder="Enter Your Address:" required>
          </div>
          
          
          </div>
        
  
        <div class="button">
          <input type="submit" value="Submit">

        </div>
        

      </form>
    </div>
  </div>
</body>
</html>