<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <!---<title> Responsive Registration Form | CodingLab </title>--->
    <link rel="stylesheet" href="style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>MoveBold Foundation-Registration Form-</title>
   </head>
<body>
<?php
// define variables and set to empty values
//$nameErr = $emailErr = $genderErr = $websiteErr = "";
//$name = $email = $gender = $comment = $website = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  

  if (empty($_POST["form1"])) {
    $genderErr = "Gender is required";
  } else {
    $gender = test_input($_POST["form2"]);
  }
}


?>
<div class="container">
    <center><h1>MoveBold Foundation</h1></center>
    

    </p></center>
    <div class="title">Become a Volunteer</div>
    <div class="content">
      <form action="form2.php">

    
 <div class="gender-details">
          <input type="radio" name="select" id="dot-1">
          <input type="radio" name="select" id="dot-2">
          
          <span class="gender-title">Select Plan</span>
          <div class="category">
            <label for="dot-1">
            <span class="dot one"></span>
            <span class="select">For 1 Year</span>
          </label>
          <label for="dot-2">
            <span class="dot two"></span>
            <span class="select">For Life Time</span>
          </label>
          
          </div>
    
          
        <!-- <input type="radio" name="gender" <?php if (isset($form1) && $gender=="form1") echo "checked";?> value="female">For 1 Year
  <input type="radio" name="gender" <?php if (isset($form2) && $gender=="form2") echo "checked";?> value="male">For Life Time-->
        
        


  
        <div class="button">
          <input type="submit" value="Register">
          
        </div>
        
      </form>
    </div>
  </div>
</body>
</html>