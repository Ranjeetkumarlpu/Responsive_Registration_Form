<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <!---<title> Responsive Registration Form | CodingLab </title>--->
    <link rel="stylesheet" href="style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>MoveBold Foundation-Registration Form-</title>
   </head>
<body>
  <div class="container">
    <center><h1>MoveBold Foundation</h1></center>
    
    <div class="title">Become a Volunteer For 1 Year</div>
    <div class="content">
      <form action="index.php">
        <div class="user-details">
          <div class="input-box">
            <span class="details">Full Name</span>
            <input type="text" placeholder="Enter your name" required>
          </div>
          <div class="input-box">
            <span class="details">Father/Spouse Name</span>
            <input type="text" placeholder="Enter your Father/Spouse Name" required>
          </div>
          <div class="input-box">
            <span class="details">Email</span>
            <input type="Email" placeholder="Enter your email" required>
          </div>
          <div class="input-box">
            <span class="details">Phone Number</span>
            <input type="text" placeholder="Enter your number" required>
          </div>
          <div class="input-box">
            <span class="details">Whatsapp No.</span>
            <input type="text" placeholder="Enter your Whatsapp No." required>
          </div>
          <div class="input-box">
            <span class="details">DOB</span>
            <input type="date" placeholder="Enter Your DOB" required>
          </div>
          <div class="input-box">
            <span class="details">Blood Group</span>
            <input type="text" placeholder="Enter Your Blood Group" required>
          </div>
          <div class="input-box">
            <span class="details">Qualification</span>
            <input type="text" placeholder="Enter Your Qualification" required>
          </div>
          <div class="input-box">
            <span class="details">Occupation</span>
            <input type="text" placeholder="Enter Your Occupation " required>
          </div>
          <div class="input-box">
            <span class="details">Residence</span>
            <input type="text" placeholder="Enter Your Residence" required>
          </div>
          <div class="input-box">
            <span class="details">Block</span>
            <input type="text" placeholder="Enter Your Block" required>
          </div>
          <div class="input-box">
            <span class="details">District</span>
            <input type="text" placeholder="Enter Your District" required>
          </div>
          <div class="input-box">
            <span class="details">State</span>
            <input type="text" placeholder="Enter Your State" required>
          </div>
          <div class="input-box">
            <span class="details">PIN</span>
            <input type="text" placeholder="Enter Your PIN" required>
          </div>
        </div>
        
  
        <div class="button">
          <input type="submit" value="Register">

          <!--<script type="text/javascript">
            alert("Application Registred SuccessFully")
          </script>-->

        </div>
        
      </form>
    </div>
  </div>
</body>
</html>