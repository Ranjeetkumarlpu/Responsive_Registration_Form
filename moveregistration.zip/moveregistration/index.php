<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <!---<title> Responsive Registration Form | CodingLab </title>--->
    <link rel="stylesheet" href="style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>MoveBold Foundation-Registration Form-</title>
   </head>
<body>
  <div class="container">
    <center><h1>MoveBold Foundation</h1></center>
    

    </p></center>
    <div class="title">Become a Volunteer</div>
    <div class="content">
      <form action="otp.php">
        <div class="user-details">
          <div class="input-box">
            <span class="details">Enter Mobile No.</span>
            <input type="text" placeholder="Enter your Mobile No." required>
          </div>
          
          </div>
        
  
        <div class="button">
          <input type="submit" value="Register">
          <script type="text/javascript">
            alert("Application Registred SuccessFully")
          </script>
          
        </div>
        
      </form>
    </div>
  </div>
  
</body>
</html>